import java.util.ArrayList;

import common.Player;
import game.Game;

public class Main {

	public static void main(String[] args) {
		Game game = new Game();
		game.startGame();
		
	}

}
