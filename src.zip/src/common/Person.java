package common;

public interface Person {
	
	public boolean enterance();
}